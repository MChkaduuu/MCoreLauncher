#!/usr/bin/env python3
"""
Generates the neon underglow textures, models and item definition (Minecraft 1.21.4+ item model format).
    pip install pillow numpy
    python generate_neon_textures.py

The numbers below MUST match the constants at the top of NeonManager.java
(CANVAS_ASPECT, FILL_X, FILL_Z, LEVELS).
"""
import json
import os

import numpy as np
from PIL import Image

W, H = 128, 208                 # texture size, ratio 1 : 1.625  (CANVAS_ASPECT)
FOOT_W, FOOT_H = 71, 151        # car footprint inside the canvas (FILL_X = 71/128, FILL_Z = 151/208)
CORNER = 16                     # rounded corner radius of the footprint, px
LEVELS = 8                      # neon_0 (invisible) .. neon_7 (full)
MAX_ALPHA = 0.88                # opacity of the brightest part at level 7
SIGMA = 10.5                    # softness of the glow outside the footprint, px
PLATEAU = 2.0                   # px of full brightness right at the car edge

ROOT = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(ROOT, "assets/mcore/textures/item/cosmetics")   # must be under textures/item/ (or block/) to be stitched into the atlas
MDL = os.path.join(ROOT, "assets/mcore/models/cosmetics")
ITM = os.path.join(ROOT, "assets/mcore/items/cosmetics")


def base_alpha():
    ys, xs = np.mgrid[0:H, 0:W].astype(np.float64)
    cx, cz = (W - 1) / 2.0, (H - 1) / 2.0
    hx, hz = FOOT_W / 2.0, FOOT_H / 2.0
    # signed distance to a rounded rectangle (negative inside)
    qx = np.abs(xs - cx) - (hx - CORNER)
    qz = np.abs(ys - cz) - (hz - CORNER)
    outside = np.hypot(np.maximum(qx, 0), np.maximum(qz, 0))
    inside = np.minimum(np.maximum(qx, qz), 0)
    sdf = outside + inside - CORNER

    d = np.maximum(sdf - PLATEAU, 0.0)
    glow = np.exp(-0.5 * (d / SIGMA) ** 2)

    # under the car itself (mostly hidden): softer, a bit darker towards the middle
    depth = np.clip(-sdf / 30.0, 0, 1)
    under = 0.62 - 0.22 * depth
    a = np.where(sdf <= 0, under, glow)

    # fade to exactly 0 before the canvas border so there is never a hard edge
    edge = np.minimum.reduce([xs, W - 1 - xs, ys, H - 1 - ys])
    a *= np.clip(edge / 12.0, 0, 1) ** 1.5
    return np.clip(a, 0, 1)


def main():
    for p in (TEX, MDL, ITM):
        os.makedirs(p, exist_ok=True)
    a = base_alpha()
    for lvl in range(LEVELS):
        mult = lvl / (LEVELS - 1)
        alpha = np.round(a * MAX_ALPHA * mult * 255).astype(np.uint8)
        img = np.zeros((H, W, 4), dtype=np.uint8)
        img[..., 0:3] = 255                      # white: the colour comes from the tint (custom_model_data.colors)
        img[..., 3] = alpha
        Image.fromarray(img, "RGBA").save(os.path.join(TEX, f"neon_{lvl}.png"))

        model = {
            "textures": {"0": f"mcore:item/cosmetics/neon_{lvl}", "particle": f"mcore:item/cosmetics/neon_{lvl}"},
            # 1 block wide, 1.625 long, lying flat at the centre height (y=8) so the display origin is the plane
            "elements": [{
                "from": [0, 8, -5], "to": [16, 8, 21],
                "shade": False,
                "faces": {
                    # only the top face: two coplanar faces would z-fight
                    "up": {"uv": [0, 0, 16, 16], "texture": "#0", "tintindex": 0},
                },
            }],
        }
        with open(os.path.join(MDL, f"neon_{lvl}.json"), "w") as f:
            json.dump(model, f, indent=2)

    tint = [{"type": "minecraft:custom_model_data", "index": 0, "default": 16777215}]
    entries = [{
        "threshold": lvl,
        "model": {"type": "minecraft:model", "model": f"mcore:cosmetics/neon_{lvl}", "tints": tint},
    } for lvl in range(LEVELS)]
    item = {"model": {
        "type": "minecraft:range_dispatch",
        "property": "minecraft:custom_model_data",
        "index": 0,
        "entries": entries,
        "fallback": {"type": "minecraft:model", "model": f"mcore:cosmetics/neon_{LEVELS - 1}", "tints": tint},
    }}
    with open(os.path.join(ITM, "neon.json"), "w") as f:
        json.dump(item, f, indent=2)
    print("done")


if __name__ == "__main__":
    main()
