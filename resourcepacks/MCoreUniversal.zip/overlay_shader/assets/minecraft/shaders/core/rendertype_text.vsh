#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// ---- MCoreUniversal: payday popup ------------------------------------------------------------
// The payday popup is a boss-bar title (centred at the top of the screen) made of glyphs with three
// special, practically invisible tint colours. Its total width is exactly POPUP_WIDTH gui pixels, so
// its left edge is at (centre - POPUP_WIDTH / 2). Here that edge is moved to POPUP_MARGIN, i.e. to the
// top-left corner. Only GUI text (orthographic projection) with those exact colours is touched.
const float POPUP_WIDTH = 150.0;
const float POPUP_MARGIN = 4.0;

bool isPopupColor(vec4 c) {
    ivec3 k = ivec3(c.rgb * 255.0 + 0.5);
    return k == ivec3(255, 255, 254) || k == ivec3(255, 254, 255) || k == ivec3(254, 218, 69);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    if (ProjMat[3][3] > 0.5 && ProjMat[0][0] > 0.0 && isPopupColor(Color)) {
        float guiWidth = 2.0 / ProjMat[0][0];
        float centre = floor(guiWidth * 0.5 + 0.001);
        float shiftGui = POPUP_MARGIN - (centre - POPUP_WIDTH * 0.5);
        gl_Position.x += shiftGui * ProjMat[0][0];
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
